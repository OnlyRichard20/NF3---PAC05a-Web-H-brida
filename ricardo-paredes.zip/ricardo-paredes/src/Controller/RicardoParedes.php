<?php
    namespace App\Controller;
    use Symfony\Component\Routing\Annotation\Route;
    use Symfony\Component\HttpFoundation\Response;

    class RicardoParedes{
        public function Prueba(){
            /**
             * @Route("/")
             */
            return new Response('Prueba 2!');
        }
        /**
         * @Route("/esto_es_una/{slug}")
         */
        public function mostrar($slug)
        {
            return new Response(sprintf(
                'Future page to show the article: "%s"',
                $slug
            ));
        }
    }